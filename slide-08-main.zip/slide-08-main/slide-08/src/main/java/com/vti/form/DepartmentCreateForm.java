package com.vti.form;

import com.vti.entity.Account;
import com.vti.entity.Department;
import com.vti.validation.DepartmentNameNotExists;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.*;
import java.util.List;

@Getter
@Setter
public class DepartmentCreateForm {
    @NotBlank(message = "Department name must NOT be blank.")
    @Length(max = 50, message = "Department has max 50 characters.")
    @DepartmentNameNotExists
    private String name;

    @PositiveOrZero(message = "Department total members required 1 members.")
    @NotNull(message = "Deparment total members must NOT be null.")
    private Integer totalMembers;

    @Pattern(
            regexp = "DEVELOPER|TESTER|SCRUM_MASTER|PROJECT_MANAGER",
            message = "Department type must be DEVELOPER, TESTER, SCRUM_MASTER or PROJECT_MANAGER"
    )
    private String type;

    private List<Account> accounts;

    @Getter
    @Setter
    public static class Account {
        private String username;
    }
}
